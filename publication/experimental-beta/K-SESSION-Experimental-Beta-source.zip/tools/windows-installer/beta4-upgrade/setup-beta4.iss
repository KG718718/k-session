#ifndef Payload
  #error Payload required
#endif
#ifndef Generated
  #error Generated required
#endif
#ifndef Output
  #error Output required
#endif
#ifdef FreshTrial
  #if defined(FaultCancel) || defined(FaultCopy) || defined(FaultPostCopy) || defined(SequenceDiagnostic)
    #error FreshTrial cannot include fault or sequence fixtures
  #endif
#endif
#include AddBackslash(Generated) + "identity.iss"
#if VER != EncodeVer(6, 7, 3)
  #error Exact Inno Setup 6.7.3 required
#endif
[Setup]
AppId=KSESSION-Beta-Installer-v1
AppName=K⁺-SESSION Beta
AppVersion=1.1.0-beta.4
AppVerName=K⁺-SESSION Beta — Installer 1.1.0-beta.4 (Unsigned)
VersionInfoVersion=1.1.0.0
VersionInfoDescription=K-SESSION Unsigned Beta Installer
DefaultDirName={localappdata}\Programs\K-SESSION-Beta
DefaultGroupName=K⁺-SESSION
PrivilegesRequired=lowest
ArchitecturesAllowed=x64os
ArchitecturesInstallIn64BitMode=x64os
MinVersion=10.0.10240
DisableDirPage=yes
DisableProgramGroupPage=yes
DisableWelcomePage=yes
DisableReadyPage=yes
UsePreviousAppDir=no
UsePreviousGroup=no
UsePreviousTasks=no
UninstallFilesDir={app}\uninstall
UninstallDisplayName=K⁺-SESSION Beta
UninstallDisplayIcon={app}\program\K-SESSION.exe
CloseApplications=no
RestartApplications=no
RestartIfNeededByRun=no
AlwaysRestart=no
SetupLogging=yes
WizardStyle=modern
Compression=lzma2
SolidCompression=yes
OutputDir={#Output}
#ifdef FreshTrial
OutputBaseFilename=K-SESSION-Fresh-Trial-1.1.0-beta.4
#else
OutputBaseFilename=K-SESSION-Setup-1.1.0-beta.4
#endif
InfoBeforeFile={#Generated}\install-info.txt

[Files]
#include AddBackslash(Generated) + "files.iss"
Source: "{#Generated}\build-info.json"; DestDir: "{app}\uninstall"; Flags: ignoreversion; Check: IsFreshInstall
Source: "{#Generated}\installer-manifest.json"; DestDir: "{app}\uninstall"; Flags: ignoreversion; Check: IsFreshInstall
Source: "{#Generated}\build-info.json"; DestDir: "{tmp}\ksession-upgrade-v2\metadata"; Flags: ignoreversion; Check: IsUpgradeInstall
Source: "{#Generated}\installer-manifest.json"; DestDir: "{tmp}\ksession-upgrade-v2\metadata"; Flags: ignoreversion; Check: IsUpgradeInstall
Source: "{#Generated}\LICENSE-Inno-Setup.txt"; DestDir: "{app}\uninstall"; Flags: ignoreversion
Source: "{#Generated}\instance-binding.ini"; DestDir: "{app}\uninstall"; Flags: ignoreversion; AfterInstall: WriteInstanceBinding; Check: IsFreshInstall
Source: "{#Payload}\K-SESSION.exe"; DestName: "ksession-location-check.exe"; Flags: dontcopy
Source: "{#Payload}\runtime\node.exe"; DestName: "ksession-beta4-node.exe"; Flags: dontcopy
#ifndef FreshTrial
Source: "{#Generated}\approved-identity-bundle.json"; Flags: dontcopy
Source: "{#Generated}\upgrade-detection.cjs"; Flags: dontcopy
Source: "{#Generated}\upgrade-preflight.cjs"; Flags: dontcopy
Source: "{#Generated}\upgrade-gate.cjs"; Flags: dontcopy
Source: "{#Generated}\upgrade-gate-cli.cjs"; Flags: dontcopy
#ifdef SequenceDiagnostic
Source: "{#Generated}\sequence-identity.cjs"; Flags: dontcopy
#endif
Source: "{#Generated}\upgrade-transaction.cjs"; Flags: dontcopy
Source: "{#Generated}\upgrade-transaction-cli.cjs"; Flags: dontcopy
Source: "{#Generated}\runtime-common.cjs"; Flags: dontcopy
Source: "{#Generated}\public-startup.js"; Flags: dontcopy
Source: "{#Generated}\public-config-store.js"; Flags: dontcopy
Source: "{#Generated}\tax-config.js"; Flags: dontcopy
Source: "{#Generated}\invoice-access-policy.js"; Flags: dontcopy
Source: "{#Generated}\service-fee-config.js"; Flags: dontcopy
Source: "{#Generated}\bonus-config.js"; Flags: dontcopy
#endif

[Icons]
Name: "{userdesktop}\K⁺-SESSION"; Filename: "{app}\program\K-SESSION.exe"; Parameters: "--instance ""{code:SelectedInstance}"""; WorkingDir: "{app}\program"
Name: "{userprograms}\K⁺-SESSION"; Filename: "{app}\program\K-SESSION.exe"; Parameters: "--instance ""{code:SelectedInstance}"""; WorkingDir: "{app}\program"

[Run]
Filename: "{app}\program\K-SESSION.exe"; Parameters: "--instance ""{code:SelectedInstance}"""; Description: "启动 K⁺-SESSION"; Flags: nowait postinstall skipifsilent; Check: CanLaunchInstalled

[Code]
#ifdef FreshTrial
type
  TFreshFindData = record
    Attributes, CreationLow, CreationHigh, AccessLow, AccessHigh,
    WriteLow, WriteHigh, SizeHigh, SizeLow, Reserved0, Reserved1: LongWord;
    Name: array[0..259] of Char;
    AlternateName: array[0..13] of Char;
  end;
#endif
const
  ProductKey = 'Software\Microsoft\Windows\CurrentVersion\Uninstall\KSESSION-Beta-Installer-v1_is1';
  BindingKey = 'Software\KSESSION\Beta\InstallerBinding';
  RunningMessage = 'K⁺-SESSION 正在运行或实例被占用。请保存当前操作，使用 K⁺-SESSION 窗口“停止服务”，再继续安装/卸载。不会强制关闭程序。';
  ExistingMessage = '已检测到 K⁺-SESSION Beta，请先停止并卸载当前版本后再安装。业务数据会保留。';
var
#ifdef FreshTrial
  FreshStartupHash: String;
  FreshStartupContext, FreshStartupLastContext, FreshStartupLastStage: String;
  FreshStartupFirstFailureContext, FreshStartupFirstFailureStage, FreshStartupCleanupFailureStage: String;
  FreshStartupCleanupVerified: Boolean;
  FreshStartupCreated, FreshInstallCompleted: Boolean;
#endif
  InstanceLock, LauncherLock, NodeLock: LongWord;
  DataPage: TInputDirWizardPage;
  UpgradePage: TOutputMsgWizardPage;
  PriorInstance, ConfirmedInstance, LocationChecker: String;
  UpgradeMode, TransactionPrepared, TransactionSwapped, TransactionFinalized, PostInstallFailed: Boolean;
  PriorDisplayName, PriorDisplayVersion, PriorInstallRoot, PriorUninstallString: String;
  PriorBindingRoot, PriorBindingInstance, UpgradeRequest, UpgradePlan: String;
  PriorProduct64Snapshot, PriorBinding64Snapshot, PriorProduct32Snapshot, PriorBinding32Snapshot: String;
  PriorProduct64Hash, PriorBinding64Hash, PriorProduct32Hash, PriorBinding32Hash: String;
  PriorProduct32Exists, PriorBinding32Exists: Boolean;
#ifdef FaultCancel
  FaultCancelIssued: Boolean;
#endif
#ifdef FaultCopy
  FaultCopyIssued: Boolean;
#endif
function CreateFileW(Name: String; Access, Share: LongWord; SA: LongWord; Creation, Flags, Template: LongWord): LongWord;
external 'CreateFileW@kernel32.dll stdcall';
function CloseHandle(H: LongWord): Boolean;
external 'CloseHandle@kernel32.dll stdcall';
function GetFileAttributesW(Name: String): LongWord;
external 'GetFileAttributesW@kernel32.dll stdcall';
function GetLastErrorCode: LongWord;
external 'GetLastError@kernel32.dll stdcall';
#ifdef FreshTrial
function MoveFileW(Existing, NewName: String): Boolean;
external 'MoveFileW@kernel32.dll stdcall';
function FreshFindFirst(Name: String; var Data: TFreshFindData): LongWord;
external 'FindFirstFileW@kernel32.dll stdcall';
function FreshFindNext(H: LongWord; var Data: TFreshFindData): Boolean;
external 'FindNextFileW@kernel32.dll stdcall';
function FreshFindClose(H: LongWord): Boolean;
external 'FindClose@kernel32.dll stdcall';
function FreshRegOpen(Root: LongWord; Key: String; Options, Access: LongWord; var H: LongWord): Longint;
external 'RegOpenKeyExW@advapi32.dll stdcall';
function FreshRegClose(H: LongWord): Longint;
external 'RegCloseKey@advapi32.dll stdcall';
#endif

procedure ReleaseLocks;
begin
  if InstanceLock <> 0 then begin CloseHandle(InstanceLock); InstanceLock := 0; end;
  if LauncherLock <> 0 then begin CloseHandle(LauncherLock); LauncherLock := 0; end;
  if NodeLock <> 0 then begin CloseHandle(NodeLock); NodeLock := 0; end;
end;

function SameInstallRoot(A, B: String): Boolean;
begin
  Result := CompareText(RemoveBackslashUnlessRoot(A), RemoveBackslashUnlessRoot(B)) = 0;
end;

function Overlaps(A, B: String): Boolean;
begin
  A := Lowercase(AddBackslash(RemoveBackslashUnlessRoot(A)));
  B := Lowercase(AddBackslash(RemoveBackslashUnlessRoot(B)));
  Result := (Pos(A, B) = 1) or (Pos(B, A) = 1);
end;

function LegacyInstance: String;
begin
  { Same LOCALAPPDATA contract as the unchanged Launcher; tests use a fresh E profile. }
  Result := AddBackslash(GetEnv('LOCALAPPDATA')) + 'K-SESSION\Beta\instance';
  if (Length(GetEnv('LOCALAPPDATA')) < 3) or (Copy(GetEnv('LOCALAPPDATA'), 2, 2) <> ':\') then
    RaiseException('无法定位当前用户数据目录。');
end;

function SelectedInstance(Param: String): String;
begin
  if IsUninstaller then
    Result := GetIniString('Installation', 'Instance', '', ExpandConstant('{app}\uninstall\instance-binding.ini'))
  else if UpgradeMode then Result := PriorBindingInstance
  else Result := DataPage.Values[0];
end;

function BetaInstance: String;
begin
  Result := SelectedInstance('');
  if Result = '' then RaiseException('数据位置绑定缺失；不会使用其他默认目录。');
end;

procedure InitializeWizard;
var Saved: String;
begin
  PriorInstance := '';
  if UpgradeMode then begin PriorInstance := PriorBindingInstance; Saved := PriorBindingInstance; end
  else begin
    Saved := LegacyInstance;
    if RegQueryStringValue(HKCU64, BindingKey, 'Instance', PriorInstance) and (PriorInstance <> '') then Saved := PriorInstance
    else if DirExists(Saved) then PriorInstance := Saved;
  end;
  DataPage := CreateInputDirPage(wpInfoBefore, '业务数据与附件保存位置', '请选择长期稳定的数据目录（不是程序安装目录）',
    '项目附件、发票附件、备份及业务数据会保存在这里。'#13#10 +
    '卸载K⁺-SESSION不会删除这里的数据，请选择长期稳定的位置。'#13#10 +
    '选择其他位置不会自动移动原有数据；原账号和附件仍留在原位置。', False, '');
  DataPage.Add('业务数据与附件目录：');
  DataPage.Values[0] := Saved;
  Saved := ExpandConstant('{param:INSTANCE|}');
  if Saved <> '' then DataPage.Values[0] := Saved;
  UpgradePage := CreateOutputMsgPage(wpInfoBefore, '升级现有 K⁺-SESSION Beta', '将沿用原业务数据与附件位置',
    '原数据位置：' + PriorBindingInstance + #13#10#13#10 + '升级不会移动或删除业务数据与附件。');
end;

function ShouldSkipPage(PageID: Integer): Boolean;
begin
  Result := (UpgradeMode and (PageID = DataPage.ID)) or ((not UpgradeMode) and (PageID = UpgradePage.ID));
end;

function IsFreshInstall: Boolean;
begin Result := not UpgradeMode; end;
function IsUpgradeInstall: Boolean;
begin Result := UpgradeMode; end;

#ifdef FreshTrial
{ Read-only, fail closed even when a directory cannot be enumerated. }
function FreshSafeDirectoryChain(P: String): Boolean;
var A, E: LongWord;
begin
  Result := False;
  if (Length(P) < 7) or (Copy(P, 2, 2) <> ':\') or (CompareText(ExpandFileName(P), P) <> 0) then exit;
  while Length(P) > 3 do begin
    A := GetFileAttributesW(P);
    if A = $FFFFFFFF then begin
      E := DLLGetLastError;
      if (E <> 2) and (E <> 3) then exit;
    end else if ((A and $10) = 0) or ((A and $400) <> 0) then exit;
    P := ExtractFileDir(P);
  end;
  Result := True;
end;

function FreshEmptyLocation(P: String): Boolean;
var A, E, H: LongWord; F: TFreshFindData; N: String; I: Integer;
begin
  Result := False;
  if not FreshSafeDirectoryChain(P) then exit;
  A := GetFileAttributesW(P);
  if A = $FFFFFFFF then begin
    E := DLLGetLastError;
    Result := (E = 2) or (E = 3);
    exit;
  end;
  if ((A and $10) = 0) or ((A and $400) <> 0) then exit;
  H := FreshFindFirst(AddBackslash(P) + '*', F);
  if H = $FFFFFFFF then exit;
  try
    repeat
      N := ''; I := 0;
      while (I <= 259) and (F.Name[I] <> #0) do begin N := N + F.Name[I]; I := I + 1; end;
      if (N <> '.') and (N <> '..') then exit;
    until not FreshFindNext(H, F);
    E := DLLGetLastError;
    Result := E = 18; { ERROR_NO_MORE_FILES only }
  finally
    if not FreshFindClose(H) then Result := False;
  end;
end;

function FreshRegistryAbsent(Root, View: LongWord; Key: String): Boolean;
var H: LongWord; E: Longint;
begin
  E := FreshRegOpen(Root, Key, 0, $20019 or View, H);
  Result := (E = 2) or (E = 3);
  if E = 0 then begin FreshRegClose(H); Result := False; end;
end;

function FreshRegistrationOrBinding: Boolean;
begin
  Result := not (FreshRegistryAbsent($80000001, $100, ProductKey) and FreshRegistryAbsent($80000001, $200, ProductKey) and
    FreshRegistryAbsent($80000002, $100, ProductKey) and FreshRegistryAbsent($80000002, $200, ProductKey) and
    FreshRegistryAbsent($80000001, $100, BindingKey) and FreshRegistryAbsent($80000001, $200, BindingKey) and
    FreshRegistryAbsent($80000002, $100, BindingKey) and FreshRegistryAbsent($80000002, $200, BindingKey));
end;
#endif
function CheckDataLocation(Prepare: Boolean): String;
var Code: Integer; Mode: String;
begin
  Result := '';
#ifdef FreshTrial
  if not Prepare and not FreshEmptyLocation(BetaInstance) then begin
    Log('KSESSION_FRESH_REJECT_INSTANCE');
    Result := '全新试用拒绝已有实例、非空或不可检查的数据目录。不会修改原数据。'; exit;
  end;
#endif
  if (PriorInstance <> '') and (CompareText(BetaInstance, PriorInstance) = 0) and not DirExists(PriorInstance) then begin
    Log('KSESSION_DATA_PRIOR_MISSING'); Result := '上次数据目录不可用。请先恢复磁盘或重新选择；不会静默创建空目录。'; exit;
  end;
  if LocationChecker = '' then begin
    ExtractTemporaryFile('ksession-location-check.exe'); LocationChecker := ExpandConstant('{tmp}\ksession-location-check.exe');
  end;
  Mode := '--check-install-instance'; if Prepare then Mode := '--prepare-install-instance';
  if not Exec(LocationChecker, Mode + ' "' + WizardDirValue + '" "' + BetaInstance + '"', '', SW_HIDE, ewWaitUntilTerminated, Code) then Code := 99;
  if Code <> 0 then begin
    Log('KSESSION_DATA_REJECT_' + IntToStr(Code));
    case Code of
      10: Result := '请选择绝对本地固定盘路径，不使用网络、盘根或特殊字符路径。';
      11: Result := '业务数据不能放在程序安装目录内，也不能与程序目录交叠。';
      12: Result := '不能使用Windows系统或Program Files目录保存业务数据。';
      13: Result := '数据路径包含链接、重解析点或不可安全访问的内容，已拒绝。';
      14: Result := '所选目录非空且不是可识别的K⁺-SESSION实例，或数据结构损坏。不会删除或初始化其内容。';
      15: Result := '所选数据位置不可写或不可访问。不会请求管理员权限。';
      else Result := '无法验证数据目录；安装已停止。';
    end;
  end;
end;

function ConfirmDataChoice: Boolean;
begin
  Result := True;
  if (PriorInstance <> '') and (CompareText(BetaInstance, PriorInstance) <> 0) and (CompareText(ConfirmedInstance, BetaInstance) <> 0) then begin
    if WizardSilent then Result := ExpandConstant('{param:CONFIRMDATACHANGE|0}') = '1'
    else Result := MsgBox('这是另一个数据位置，不会自动移动原账号、附件或业务数据。确认使用新位置？', mbConfirmation, MB_YESNO) = IDYES;
    if Result then ConfirmedInstance := BetaInstance;
  end;
end;

function NextButtonClick(CurPageID: Integer): Boolean;
var Error: String;
begin
  Result := True;
  { Silent installs use PrepareToInstall's error return, never a blocking custom MsgBox. }
  if WizardSilent then exit;
  if CurPageID = DataPage.ID then begin
    Error := CheckDataLocation(False);
    if Error <> '' then begin MsgBox(Error, mbError, MB_OK); Result := False; exit; end;
    Result := ConfirmDataChoice;
  end;
end;

procedure WriteInstanceBinding;
var P: String;
begin
  P := ExpandConstant('{app}\uninstall\instance-binding.ini');
  if not SetIniString('Installation', 'Schema', '1', P) or
     not SetIniString('Installation', 'InstallRoot', ExpandConstant('{app}'), P) or
     not SetIniString('Installation', 'Instance', BetaInstance, P) then RaiseException('无法保存安装数据目录绑定。');
end;

function SafeDirectoryChain(P: String): Boolean;
var Q: String; Attr: LongWord;
begin
  Result := False;
  P := RemoveBackslashUnlessRoot(P);
  if (Length(P) < 7) or (Length(ExtractFileDrive(P)) <> 2) or (Copy(P, 2, 2) <> ':\') then exit;
  if CompareText(ExpandFileName(P), P) <> 0 then exit;
  Q := P;
  while Length(Q) > 3 do begin
    Attr := GetFileAttributesW(Q);
    if Attr <> $FFFFFFFF then begin
      if (Attr and $400) <> 0 then exit;
      if (Attr and $10) = 0 then exit;
    end;
    Q := ExtractFileDir(Q);
  end;
  Result := True;
end;

function SafePath(P: String): Boolean;
begin
  Result := False;
  if not SafeDirectoryChain(P) then exit;
  P := RemoveBackslashUnlessRoot(P);
  if Overlaps(P, BetaInstance) then exit;
  if Overlaps(P, ExpandConstant('{win}')) then exit;
  Result := True;
end;

function NonEmpty(P: String): Boolean;
var F: TFindRec;
begin
  Result := False;
  if FindFirst(AddBackslash(P) + '*', F) then begin
    try
      repeat
        if (F.Name <> '.') and (F.Name <> '..') then begin Result := True; exit; end;
      until not FindNext(F);
    finally FindClose(F); end;
  end;
end;

#ifdef FreshTrial
function FreshStartupPath: String;
begin Result := ExpandConstant('{userstartup}\K-SESSION Fresh Trial.lnk'); end;

function FreshFileAbsent(P: String): Boolean;
var A, E: LongWord;
begin
  Result := False;
  if not FreshSafeDirectoryChain(ExtractFileDir(P)) then exit;
  A := GetFileAttributesW(P);
  if A <> $FFFFFFFF then exit;
  E := DLLGetLastError;
  Result := (E = 2) or (E = 3);
end;

function FreshStartupAbsent: Boolean;
var A, E: LongWord;
begin
  Result := False;
  if not FreshSafeDirectoryChain(ExpandConstant('{userstartup}')) then exit;
  A := GetFileAttributesW(FreshStartupPath);
  if A <> $FFFFFFFF then exit;
  E := DLLGetLastError;
  Result := (E = 2) or (E = 3);
end;

procedure FreshStartupStage(Stage: String);
begin
  if FreshStartupContext = '' then FreshStartupContext := 'UNINSTALL_VERIFY';
  FreshStartupLastContext := FreshStartupContext; FreshStartupLastStage := Stage;
  if (Pos('MISMATCH', Stage) > 0) or (Pos('MISSING', Stage) > 0) or (Pos('UNSAFE', Stage) > 0) or
     (Pos('REJECTED', Stage) > 0) or (Pos('FAILED', Stage) > 0) or (Pos('EXCEPTION', Stage) > 0) or
     (Stage = 'CLEANUP_IDENTITY_UNKNOWN') then begin
    if FreshStartupFirstFailureStage = '' then begin FreshStartupFirstFailureContext := FreshStartupContext; FreshStartupFirstFailureStage := Stage; end;
    if FreshStartupContext = 'CLEANUP_VERIFY' then FreshStartupCleanupFailureStage := Stage;
  end;
  Log('KSESSION_FRESH_STARTUP_EVENT_' + FreshStartupContext + '_' + Stage);
end;

#include AddBackslash(Generated) + "fresh-startup-identity.iss"

function FreshStartupMatches(ExpectedHash: String): Boolean;
var Shell, Link: Variant; P: String; A, Pin: LongWord; I: TFreshFileId128; ExactArguments: Boolean;
begin
  Result := False; Pin := 0;
  try
   try
    if (FreshStartupContext <> 'INSTALL_VERIFY') and (FreshStartupContext <> 'CLEANUP_VERIFY') then FreshStartupContext := 'UNINSTALL_VERIFY';
    P := FreshStartupPath;
    FreshStartupStage('VERIFY_DIRECTORY');
    if not FreshSafeDirectoryChain(ExtractFileDir(P)) then begin FreshStartupStage('DIRECTORY_UNSAFE'); exit; end;
    FreshStartupStage('VERIFY_ATTRIBUTES'); A := GetFileAttributesW(P);
    if (A = $FFFFFFFF) or ((A and $400) <> 0) or ((A and $10) <> 0) then begin FreshStartupStage('ATTRIBUTES_REJECTED'); exit; end;
    Pin := CreateFileW(P, $80000000, 1, 0, 3, $00200000, 0);
    if Pin = $FFFFFFFF then begin Pin := 0; FreshStartupStage('ATTRIBUTES_REJECTED'); exit; end;
    if not FreshReadId(Pin, False, I) then begin FreshStartupStage('ATTRIBUTES_REJECTED'); exit; end;
    if (FreshStartupReference <> 0) and not FreshSameId(I, FreshStartupOwnerId) then begin FreshStartupStage('ATTRIBUTES_REJECTED'); exit; end;
    FreshStartupStage('VERIFY_EXPECTED_HASH');
    if ExpectedHash = '' then begin FreshStartupStage('EXPECTED_HASH_MISSING'); exit; end;
    FreshStartupStage('VERIFY_HASH');
    if GetSHA256OfFile(P) <> ExpectedHash then begin FreshStartupStage('HASH_MISMATCH'); exit; end;
    FreshStartupStage('COM_INITIALIZE'); Shell := CreateOleObject('WScript.Shell');
    FreshStartupStage('COM_OPEN_LINK'); Link := Shell.CreateShortcut(P);
    FreshStartupStage('TARGET_READ');
    if FreshStartupContext = 'UNINSTALL_VERIFY' then begin
      { Preserve the existing uninstall contract; its executable lock denies data reads. }
      if CompareText(Link.TargetPath, ExpandConstant('{app}\program\K-SESSION.exe')) <> 0 then begin FreshStartupStage('TARGET_MISMATCH'); exit; end;
    end else if not FreshTrustedStartupTarget(String(Link.TargetPath)) then begin
      FreshStartupStage('TARGET_DETAIL_' + FreshTargetFailureStage);
      FreshStartupStage('TARGET_MISMATCH'); exit;
    end;
    FreshStartupStage('TARGET_MATCH'); FreshStartupStage('ARGUMENTS_READ');
    ExactArguments := (Link.Arguments = '--logon --instance "' + BetaInstance + '"');
    if not ExactArguments then begin FreshStartupStage('ARGUMENTS_MISMATCH'); exit; end;
    FreshStartupStage('ARGUMENTS_MATCH'); FreshStartupStage('WORKDIR_READ');
    if CompareText(Link.WorkingDirectory, ExpandConstant('{app}\program')) <> 0 then begin FreshStartupStage('WORKDIR_MISMATCH'); exit; end;
    FreshStartupStage('WORKDIR_MATCH'); Result := True;
   except FreshStartupStage('VERIFY_EXCEPTION'); Result := False; end;
  finally
    if (Pin <> 0) and not CloseHandle(Pin) then begin
      if Result then FreshStartupStage('VERIFY_EXCEPTION')
      else Log('KSESSION_FRESH_STARTUP_CLEANUP_UNPROVEN');
      Result := False;
    end;
  end;
  if Result then FreshStartupStage('MATCHED');
end;

procedure CreateFreshStartup;
var Tmp, Made: String;
begin
  FreshStartupContext := 'CREATE'; FreshStartupStage('CREATE_ENTER');
  if not FreshStartupAbsent then begin FreshStartupStage('CREATE_PRECONDITION_REJECTED'); RaiseException('登录启动项冲突或目录不安全，拒绝覆盖。'); end;
  if not FreshBindTrustedStartupTarget then begin FreshStartupStage('CREATE_PRECONDITION_REJECTED'); RaiseException('受信任启动程序身份无法证明。'); end;
  Tmp := ExpandConstant('{tmp}\ksession-fresh-startup.lnk');
  if not FreshFileAbsent(Tmp) or not FreshPrepareStartupOwner then begin FreshStartupStage('CREATE_PRECONDITION_REJECTED'); RaiseException('登录启动项临时资源或目录身份未知。'); end;
  FreshStartupStage('CREATE_LINK');
  Made := CreateShellLink(Tmp, 'K-SESSION Fresh Trial', ExpandConstant('{app}\program\K-SESSION.exe'),
    '--logon --instance "' + BetaInstance + '"', ExpandConstant('{app}\program'), '', 0, SW_SHOWNORMAL);
  FreshStartupStage('LINK_CREATED');
  if CompareText(Made, Tmp) <> 0 then begin FreshStartupStage('RETURN_NAME_MISMATCH'); RaiseException('登录启动项格式无效。'); end;
  FreshStartupStage('CREATE_HASH');
  if not FreshCaptureStartupProducer(Tmp) then begin FreshStartupStage('CREATE_HASH_MISSING'); RaiseException('无法绑定本次创建的启动项身份。'); end;
  if FreshStartupHash = '' then begin FreshStartupStage('CREATE_HASH_MISSING'); RaiseException('无法安全创建登录启动项；不会覆盖已有项。'); end;
  FreshStartupStage('CREATE_MOVE');
  if not FreshStartupAbsent or not FreshMoveStartupProducer(Tmp) then begin
    if FreshStartupCreated then FreshStartupStage('MOVE_PROOF_FAILED') else FreshStartupStage('MOVE_REJECTED');
    RaiseException('无法安全创建登录启动项；不会覆盖已有项。');
  end;
  FreshStartupContext := 'INSTALL_VERIFY';
  if not FreshStartupMatches(FreshStartupHash) then RaiseException('登录启动项身份验证失败。');
  FreshStartupContext := 'CREATE'; FreshStartupStage('INI_WRITE');
  if not SetIniString('Startup', 'Sha256', FreshStartupHash, ExpandConstant('{app}\uninstall\fresh-startup.ini')) then begin FreshStartupStage('INI_WRITE_FAILED'); RaiseException('无法保存登录启动项身份。'); end;
  FreshStartupStage('INI_WRITTEN'); Log('KSESSION_FRESH_STARTUP_VERIFIED');
end;
#endif
function RunningProduct: Boolean;
var Locator, Service, Items, Item: Variant; I: Integer; P, R: String;
begin
  Result := True; { fail closed when process inspection is unavailable }
  try
    Locator := CreateOleObject('WbemScripting.SWbemLocator');
    Service := Locator.ConnectServer('', 'root\CIMV2');
    Items := Service.ExecQuery('SELECT Name,ExecutablePath FROM Win32_Process WHERE Name="K-SESSION.exe" OR Name="node.exe"');
    for I := 0 to Items.Count - 1 do begin
      Item := Items.ItemIndex(I);
      if not VarIsNull(Item.ExecutablePath) then begin
        P := String(Item.ExecutablePath);
        if CompareText(String(Item.Name), 'K-SESSION.exe') = 0 then begin
          R := ExtractFileDir(P);
          if FileExists(R + '\manifest\runtime-manifest.json') and FileExists(R + '\app\server.js') then exit;
        end else begin
          R := ExtractFileDir(ExtractFileDir(P));
          if FileExists(R + '\K-SESSION.exe') and FileExists(R + '\manifest\runtime-manifest.json') and FileExists(R + '\app\server.js') then exit;
        end;
      end else if CompareText(String(Item.Name), 'K-SESSION.exe') = 0 then exit;
    end;
    Result := False;
  except Log('KSESSION_PROCESS_INSPECTION_UNAVAILABLE: ' + GetExceptionMessage); end;
end;

function AcquireExistingInstanceLock: Boolean;
var P: String; H: LongWord;
begin
  Result := True;
  if InstanceLock <> 0 then exit;
  P := BetaInstance + '\.launcher.lock';
  if not FileExists(P) then begin
    Result := not UpgradeMode; { upgrade requires an existing lock object; never create one }
    exit;
  end;
  if (GetFileAttributesW(P) and $400) <> 0 then begin Result := False; exit; end;
  H := CreateFileW(P, $C0000000, 0, 0, 3, $80, 0); { OPEN_EXISTING; no write }
  Result := H <> $FFFFFFFF;
  if Result then InstanceLock := H;
end;

function HasRegistration: Boolean;
begin
  Result := RegKeyExists(HKCU64, ProductKey) or RegKeyExists(HKCU32, ProductKey);
end;

function JsonEscape(S: String): String;
begin
  Result := S;
  StringChangeEx(Result, '\', '\\', True);
  StringChangeEx(Result, '"', '\"', True);
end;

function RegistryTool(View: String): String;
begin
  if View = '64' then Result := ExpandConstant('{sys}\reg.exe')
  else Result := ExpandConstant('{syswow64}\reg.exe');
end;

function ExportRegistryKey(KeyName, FileName, View: String): Boolean;
var Code: Integer;
begin
  DeleteFile(FileName);
  Result := Exec(RegistryTool(View), 'export "HKCU\' + KeyName + '" "' + FileName + '" /y /reg:' + View,
    ExpandConstant('{tmp}'), SW_HIDE, ewWaitUntilTerminated, Code) and (Code = 0) and FileExists(FileName);
end;

function SnapshotUpgradeRegistration: Boolean;
begin
  Result := False;
  PriorProduct64Snapshot := ExpandConstant('{tmp}\ksession-product-64.reg');
  PriorBinding64Snapshot := ExpandConstant('{tmp}\ksession-binding-64.reg');
  PriorProduct32Snapshot := ExpandConstant('{tmp}\ksession-product-32.reg');
  PriorBinding32Snapshot := ExpandConstant('{tmp}\ksession-binding-32.reg');
  PriorProduct32Exists := RegKeyExists(HKCU32, ProductKey);
  PriorBinding32Exists := RegKeyExists(HKCU32, BindingKey);
  if not ExportRegistryKey(ProductKey, PriorProduct64Snapshot, '64') or
     not ExportRegistryKey(BindingKey, PriorBinding64Snapshot, '64') then exit;
  PriorProduct64Hash := GetSHA256OfFile(PriorProduct64Snapshot);
  PriorBinding64Hash := GetSHA256OfFile(PriorBinding64Snapshot);
  if (PriorProduct64Hash = '') or (PriorBinding64Hash = '') then exit;
  if PriorProduct32Exists then begin
    if not ExportRegistryKey(ProductKey, PriorProduct32Snapshot, '32') then exit;
    PriorProduct32Hash := GetSHA256OfFile(PriorProduct32Snapshot);
    if PriorProduct32Hash = '' then exit;
  end;
  if PriorBinding32Exists then begin
    if not ExportRegistryKey(BindingKey, PriorBinding32Snapshot, '32') then exit;
    PriorBinding32Hash := GetSHA256OfFile(PriorBinding32Snapshot);
    if PriorBinding32Hash = '' then exit;
  end;
  Result := True;
end;

function ReadUpgradeIdentity: Boolean;
var N, V, R, U, BR, BI: String;
begin
  Result := False;
  if not RegQueryStringValue(HKCU64, ProductKey, 'DisplayName', PriorDisplayName) or
     not RegQueryStringValue(HKCU64, ProductKey, 'DisplayVersion', PriorDisplayVersion) or
     not RegQueryStringValue(HKCU64, ProductKey, 'InstallLocation', PriorInstallRoot) or
     not RegQueryStringValue(HKCU64, ProductKey, 'UninstallString', PriorUninstallString) or
     not RegQueryStringValue(HKCU64, BindingKey, 'InstallRoot', PriorBindingRoot) or
     not RegQueryStringValue(HKCU64, BindingKey, 'Instance', PriorBindingInstance) then exit;
  if RegQueryStringValue(HKCU32, ProductKey, 'DisplayName', N) then begin
    if not RegQueryStringValue(HKCU32, ProductKey, 'DisplayVersion', V) or
       not RegQueryStringValue(HKCU32, ProductKey, 'InstallLocation', R) or
       not RegQueryStringValue(HKCU32, ProductKey, 'UninstallString', U) or
       (N <> PriorDisplayName) or (V <> PriorDisplayVersion) or (CompareText(R, PriorInstallRoot) <> 0) or
       (CompareText(U, PriorUninstallString) <> 0) then exit;
  end;
  if RegQueryStringValue(HKCU32, BindingKey, 'InstallRoot', BR) then begin
    if not RegQueryStringValue(HKCU32, BindingKey, 'Instance', BI) or
       (CompareText(BR, PriorBindingRoot) <> 0) or (CompareText(BI, PriorBindingInstance) <> 0) then exit;
  end;
  Result := (PriorDisplayName = 'K⁺-SESSION Beta') and (PriorDisplayVersion <> '') and
    (PriorInstallRoot <> '') and (PriorBindingRoot <> '') and (PriorBindingInstance <> '') and
    SnapshotUpgradeRegistration;
end;

procedure ExtractUpgradeTools;
begin
  ExtractTemporaryFile('ksession-beta4-node.exe');
  ExtractTemporaryFile('approved-identity-bundle.json');
  ExtractTemporaryFile('upgrade-detection.cjs');
  ExtractTemporaryFile('upgrade-preflight.cjs');
  ExtractTemporaryFile('upgrade-gate.cjs');
  ExtractTemporaryFile('upgrade-gate-cli.cjs');
#ifdef SequenceDiagnostic
  ExtractTemporaryFile('sequence-identity.cjs');
#endif
  ExtractTemporaryFile('upgrade-transaction.cjs');
  ExtractTemporaryFile('upgrade-transaction-cli.cjs');
  ExtractTemporaryFile('runtime-common.cjs');
  ExtractTemporaryFile('public-startup.js');
  ExtractTemporaryFile('public-config-store.js');
  ExtractTemporaryFile('tax-config.js');
  ExtractTemporaryFile('invoice-access-policy.js');
  ExtractTemporaryFile('service-fee-config.js');
  ExtractTemporaryFile('bonus-config.js');
end;

function RunNode(Script, Args: String): Boolean;
var Code: Integer;
begin
  Result := Exec(ExpandConstant('{tmp}\ksession-beta4-node.exe'), '"' + ExpandConstant('{tmp}\') + Script + '" ' + Args,
    ExpandConstant('{tmp}'), SW_HIDE, ewWaitUntilTerminated, Code) and (Code = 0);
end;

function WriteUpgradeRequest: Boolean;
var S, R: String;
begin
  UpgradeRequest := ExpandConstant('{tmp}\ksession-upgrade-request.json');
  R := RemoveBackslashUnlessRoot(PriorInstallRoot);
  S := '{"schema":1,"snapshot":{"registrations":[{"view":"64","key":"' + JsonEscape(ProductKey) +
    '","displayName":"' + JsonEscape(PriorDisplayName) + '","displayVersion":"' + JsonEscape(PriorDisplayVersion) +
    '","installLocation":"' + JsonEscape(PriorInstallRoot) + '","uninstallString":"' + JsonEscape(PriorUninstallString) +
    '"}],"bindings":[{"view":"64","key":"' + JsonEscape(BindingKey) + '","installRoot":"' + JsonEscape(PriorBindingRoot) +
    '","instance":"' + JsonEscape(PriorBindingInstance) + '"}]},"preflight":{"installRoot":"' + JsonEscape(R) +
    '","instancePath":"' + JsonEscape(PriorBindingInstance) + '","bindingFile":"' + JsonEscape(AddBackslash(R) + 'uninstall\instance-binding.ini') +
    '","registeredInstallRoot":"' + JsonEscape(PriorBindingRoot) + '","registeredInstance":"' + JsonEscape(PriorBindingInstance) +
    '","dataContractVersion":"1","appRoot":"' + JsonEscape(ExpandConstant('{tmp}')) + '"}}';
  Result := SaveStringToFile(UpgradeRequest, Utf8Encode(S), False);
end;

function WriteUpgradePlan: Boolean;
var S, R: String;
begin
  UpgradePlan := ExpandConstant('{tmp}\ksession-upgrade-plan.json');
  R := RemoveBackslashUnlessRoot(PriorInstallRoot);
  S := '{"schema":1,"installRoot":"' + JsonEscape(R) + '","instancePath":"' + JsonEscape(PriorBindingInstance) +
    '","stagedProgram":"' + JsonEscape(ExpandConstant('{tmp}\ksession-upgrade-v2\program')) +
    '","stagedMetadata":"' + JsonEscape(ExpandConstant('{tmp}\ksession-upgrade-v2\metadata')) +
    '","desktopShortcut":"' + JsonEscape(ExpandConstant('{userdesktop}\K⁺-SESSION.lnk')) +
    '","startMenuShortcut":"' + JsonEscape(ExpandConstant('{userprograms}\K⁺-SESSION.lnk')) +
    '","sourceCommit":"{#SourceCommit}","runtimeManifestHash":"{#RuntimeManifestSha256}","launcherHash":"{#LauncherSha256}","firewallHelperHash":"{#FirewallHelperSha256}","programManifestHash":"{#ProgramManifestSha256}","instanceBindingSchema":1,"upgradeFrom":"1.1.0-beta.2","upgradeTo":"1.1.0-beta.4"}';
  Result := SaveStringToFile(UpgradePlan, Utf8Encode(S), False);
end;

function CommitUpgradeTransaction: Boolean;
var Code: Integer; Started: Boolean;
begin
  Code := 79;
  Started := Exec(ExpandConstant('{tmp}\ksession-beta4-node.exe'),
    '"' + ExpandConstant('{tmp}\upgrade-transaction-cli.cjs') + '" commit "' + UpgradePlan + '"',
    ExpandConstant('{tmp}'), SW_HIDE, ewWaitUntilTerminated, Code);
  Result := Started and (Code = 0);
  if not Result then begin
    if Started and (Code = 61) then Log('KSESSION_UPGRADE_COMMIT_MANIFEST_HASH_REJECTED')
    else Log('KSESSION_UPGRADE_COMMIT_UNKNOWN');
  end;
end;

#ifdef SequenceDiagnostic
procedure LogSequenceRegistrationDetail;
var DetailCode: Integer;
begin
  if not Exec(ExpandConstant('{tmp}\ksession-beta4-node.exe'), '"' + ExpandConstant('{tmp}\sequence-identity.cjs') + '" "' +
    UpgradeRequest + '" "' + ExpandConstant('{tmp}\approved-identity-bundle.json') + '"',
    ExpandConstant('{tmp}'), SW_HIDE, ewWaitUntilTerminated, DetailCode) then begin
    Log('KSESSION_SEQUENCE_REGISTRATION_AMBIGUOUS'); exit;
  end;
  case DetailCode of
    60: Log('KSESSION_SEQUENCE_REGISTRATION_COUNT');
    61: Log('KSESSION_SEQUENCE_REGISTRATION_NAME');
    62: Log('KSESSION_SEQUENCE_REGISTRATION_SNAPSHOT');
    63: Log('KSESSION_SEQUENCE_REGISTRATION_CONFLICT');
    64: Log('KSESSION_SEQUENCE_REGISTRATION_UNINSTALL');
    66: Log('KSESSION_SEQUENCE_REGISTRATION_INCONSISTENT');
    67: Log('KSESSION_SEQUENCE_REGISTRATION_VERSION');
    68: Log('KSESSION_SEQUENCE_REGISTRATION_NAME_VERSION');
  else
    Log('KSESSION_SEQUENCE_REGISTRATION_AMBIGUOUS');
  end;
end;
#endif

function RunUpgradeGate: Boolean;
var Code: Integer;
begin
  Result := False;
  ExtractUpgradeTools;
  if not WriteUpgradeRequest then exit;
  if not Exec(ExpandConstant('{tmp}\ksession-beta4-node.exe'), '"' + ExpandConstant('{tmp}\upgrade-gate-cli.cjs') + '" --request "' +
    UpgradeRequest + '" "' + ExpandConstant('{tmp}\approved-identity-bundle.json') + '" "{#IdentityBundleSha256}"',
    ExpandConstant('{tmp}'), SW_HIDE, ewWaitUntilTerminated, Code) then begin
    Log('KSESSION_UPGRADE_GATE_PROCESS_START_FAILED'); exit;
  end;
#ifdef SequenceDiagnostic
  if Code = 50 then LogSequenceRegistrationDetail;
#endif
  case Code of
    10: Log('KSESSION_UPGRADE_GATE_ARGUMENT_INVALID');
    11: Log('KSESSION_UPGRADE_GATE_REQUEST_INVALID');
    12: Log('KSESSION_UPGRADE_GATE_BUNDLE_HASH');
    13: Log('KSESSION_UPGRADE_GATE_BUNDLE_INVALID');
    14: Log('KSESSION_UPGRADE_GATE_IDENTITY_REJECTED');
    20: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_ARGUMENT_INVALID');
    21: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_DATA_CONTRACT_UNSUPPORTED');
    22: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_APP_RESOURCE_INVALID');
    23: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_INSTALL_ROOT_INVALID');
    24: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_INSTANCE_NOT_FOUND');
    25: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_INSTANCE_PATH_UNSAFE');
    26: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_INSTANCE_UNREADABLE');
    27: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_BINDING_INVALID');
    28: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_REGISTRATION_CONFLICT');
    29: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_BINDING_CONFLICT');
    30: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_STORE_UNREADABLE');
    31: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_STORE_INVALID');
    32: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_CONFIG_INVALID');
    33: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_ORPHANED_INSTALLATION');
    34: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_STORE_VALIDATION_FAILED');
    35: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_INSTANCE_STRUCTURE_UNSAFE');
    36: Log('KSESSION_UPGRADE_GATE_PREFLIGHT_INTERNAL');
    40: Log('KSESSION_UPGRADE_GATE_CONTRACT_RESULT');
    41: Log('KSESSION_UPGRADE_GATE_CONTRACT_INSTALL_ROOT');
    42: Log('KSESSION_UPGRADE_GATE_CONTRACT_INSTANCE_PATH');
    43: Log('KSESSION_UPGRADE_GATE_CONTRACT_DATA');
    49: Log('KSESSION_UPGRADE_GATE_INTERNAL');
    50: Log('KSESSION_UPGRADE_GATE_IDENTITY_REGISTRATION');
    51: Log('KSESSION_UPGRADE_GATE_IDENTITY_BINDING');
    52: Log('KSESSION_UPGRADE_GATE_IDENTITY_PATH');
    53: Log('KSESSION_UPGRADE_GATE_IDENTITY_MANIFEST');
    54: Log('KSESSION_UPGRADE_GATE_IDENTITY_PROGRAM');
    55: Log('KSESSION_UPGRADE_GATE_IDENTITY_BUILD');
    56: Log('KSESSION_UPGRADE_GATE_IDENTITY_RUNTIME');
    57: Log('KSESSION_UPGRADE_GATE_IDENTITY_LAUNCHER');
    58: Log('KSESSION_UPGRADE_GATE_IDENTITY_INTERNAL');
  end;
  if (Code <> 0) and ((Code < 10) or (Code > 58) or ((Code > 14) and (Code < 20)) or ((Code > 36) and (Code < 40)) or ((Code > 43) and (Code < 49))) then
    Log('KSESSION_UPGRADE_GATE_UNKNOWN');
  Result := Code = 0;
end;

function PrepareUpgradeTransaction: Boolean;
begin
  Result := False;
  if not WriteUpgradePlan then exit;
  Result := RunNode('upgrade-transaction-cli.cjs', 'prepare "' + UpgradePlan + '"');
  if Result then TransactionPrepared := True;
end;

function WriteFreshInstallState: Boolean;
var S, P: String;
#ifdef FreshTrial
    TempState: String;
#endif
begin
  P := ExpandConstant('{app}\uninstall\install-state.json');
  S := '{"schema":1,"installerVersion":"1.1.0-beta.4","appVersion":"1.0.0","dataContractVersion":1,' +
    '"sourceCommit":"{#SourceCommit}","runtimeManifestHash":"{#RuntimeManifestSha256}","launcherHash":"{#LauncherSha256}","firewallHelperHash":"{#FirewallHelperSha256}",' +
    '"programManifestHash":"{#ProgramManifestSha256}","instanceBindingSchema":1,"installRoot":"' +
    JsonEscape(ExpandConstant('{app}')) + '","instancePath":"' + JsonEscape(BetaInstance) +
    '","upgradeFrom":"fresh","upgradeTo":"1.1.0-beta.4"}';
#ifdef FreshTrial
  Result := False;
  if not FreshFileAbsent(P) then exit;
  TempState := ExpandConstant('{tmp}\ksession-fresh-state.json');
  if not SaveStringToFile(TempState, Utf8Encode(S), False) then exit;
  Result := FileCopy(TempState, P, True);
#else
  Result := SaveStringToFile(P, Utf8Encode(S), False);
#endif
end;

function DeleteRegistryKeyExact(Root: Integer; KeyName: String): Boolean;
begin
  Result := True;
  if RegKeyExists(Root, KeyName) then Result := RegDeleteKeyIncludingSubkeys(Root, KeyName);
  Result := Result and not RegKeyExists(Root, KeyName);
end;

function ImportRegistryKey(FileName, View: String): Boolean;
var Code: Integer;
begin
  Result := Exec(RegistryTool(View), 'import "' + FileName + '" /reg:' + View,
    ExpandConstant('{tmp}'), SW_HIDE, ewWaitUntilTerminated, Code) and (Code = 0);
end;

function VerifyRegistryKey(KeyName, View, ExpectedHash, VerifyName: String): Boolean;
begin
  Result := ExportRegistryKey(KeyName, VerifyName, View) and
    (GetSHA256OfFile(VerifyName) = ExpectedHash);
end;

function ValidateRegistrySnapshot(FileName, ExpectedHash: String): Boolean;
var Attributes: LongWord;
begin
  Result := False;
  Attributes := GetFileAttributesW(FileName);
  if (Attributes = $FFFFFFFF) or ((Attributes and $10) <> 0) or ((Attributes and $400) <> 0) then exit;
  Result := FileExists(FileName) and (ExpectedHash <> '') and (GetSHA256OfFile(FileName) = ExpectedHash);
end;

function RestoreUpgradeRegistration: Boolean;
var VerifyProduct64, VerifyBinding64, VerifyProduct32, VerifyBinding32: String;
begin
  Result := False;
#ifdef FaultRegistryRestore
  if not SaveStringToFile(PriorProduct64Snapshot, 'synthetic-corruption', True) then begin
    Log('KSESSION_FIXTURE_REGISTRY_RESTORE_FAILURE'); exit;
  end;
  Log('KSESSION_FIXTURE_REGISTRY_RESTORE_FAILURE');
#endif
  if not ValidateRegistrySnapshot(PriorProduct64Snapshot, PriorProduct64Hash) or
     not ValidateRegistrySnapshot(PriorBinding64Snapshot, PriorBinding64Hash) then exit;
  if PriorProduct32Exists and not ValidateRegistrySnapshot(PriorProduct32Snapshot, PriorProduct32Hash) then exit;
  if PriorBinding32Exists and not ValidateRegistrySnapshot(PriorBinding32Snapshot, PriorBinding32Hash) then exit;
  if not DeleteRegistryKeyExact(HKCU64, ProductKey) or not DeleteRegistryKeyExact(HKCU64, BindingKey) or
     not DeleteRegistryKeyExact(HKCU32, ProductKey) or not DeleteRegistryKeyExact(HKCU32, BindingKey) then exit;
  if not ImportRegistryKey(PriorProduct64Snapshot, '64') or not ImportRegistryKey(PriorBinding64Snapshot, '64') then exit;
  if PriorProduct32Exists and not ImportRegistryKey(PriorProduct32Snapshot, '32') then exit;
  if PriorBinding32Exists and not ImportRegistryKey(PriorBinding32Snapshot, '32') then exit;
  if (not PriorProduct32Exists and RegKeyExists(HKCU32, ProductKey)) or
     (not PriorBinding32Exists and RegKeyExists(HKCU32, BindingKey)) then exit;
  VerifyProduct64 := ExpandConstant('{tmp}\ksession-product-64-verify.reg');
  VerifyBinding64 := ExpandConstant('{tmp}\ksession-binding-64-verify.reg');
  VerifyProduct32 := ExpandConstant('{tmp}\ksession-product-32-verify.reg');
  VerifyBinding32 := ExpandConstant('{tmp}\ksession-binding-32-verify.reg');
  if not VerifyRegistryKey(ProductKey, '64', PriorProduct64Hash, VerifyProduct64) or
     not VerifyRegistryKey(BindingKey, '64', PriorBinding64Hash, VerifyBinding64) then exit;
  if PriorProduct32Exists and not VerifyRegistryKey(ProductKey, '32', PriorProduct32Hash, VerifyProduct32) then exit;
  if PriorBinding32Exists and not VerifyRegistryKey(BindingKey, '32', PriorBinding32Hash, VerifyBinding32) then exit;
  Result := True;
end;

function VerifyFinalRegistration: Boolean;
var V, R, I, S, V32, R32: String;
begin
  Result := False;
  if not RegQueryStringValue(HKCU64, ProductKey, 'DisplayVersion', V) or (V <> '1.1.0-beta.4') or
     not RegQueryStringValue(HKCU64, ProductKey, 'InstallLocation', R) or not SameInstallRoot(R, ExpandConstant('{app}')) or
     not RegQueryStringValue(HKCU64, BindingKey, 'Instance', I) or (CompareText(I, PriorBindingInstance) <> 0) then exit;
  if RegQueryStringValue(HKCU32, ProductKey, 'DisplayVersion', V32) then begin
    if not RegQueryStringValue(HKCU32, ProductKey, 'InstallLocation', R32) or (V32 <> V) or (CompareText(R32, R) <> 0) then exit;
  end;
  S := GetIniString('Installation', 'Schema', '', ExpandConstant('{app}\uninstall\instance-binding.ini'));
  R := GetIniString('Installation', 'InstallRoot', '', ExpandConstant('{app}\uninstall\instance-binding.ini'));
  I := GetIniString('Installation', 'Instance', '', ExpandConstant('{app}\uninstall\instance-binding.ini'));
  Result := (S = '1') and (CompareText(R, ExpandConstant('{app}')) = 0) and (CompareText(I, PriorBindingInstance) = 0);
end;

function InitializeSetup: Boolean;
begin
  Result := False;
#ifdef FreshTrial
  UpgradeMode := False;
  if FreshRegistrationOrBinding then begin
    Log('KSESSION_FRESH_REJECT_REGISTRATION'); exit;
  end;
  if not FreshEmptyLocation(LegacyInstance) then begin
    Log('KSESSION_FRESH_REJECT_LEGACY_INSTANCE'); exit;
  end;
#endif
  if RunningProduct then begin Log('KSESSION_REJECT_RUNNING'); SuppressibleMsgBox(RunningMessage, mbError, MB_OK, IDOK); exit; end;
#ifndef FreshTrial
  UpgradeMode := HasRegistration;
  if UpgradeMode and not ReadUpgradeIdentity then begin
    Log('KSESSION_UPGRADE_REGISTRATION_REJECTED');
    SuppressibleMsgBox('现有安装登记缺失、冲突或损坏，无法安全升级。不会修改现有程序或数据。', mbError, MB_OK, IDOK); exit;
  end;
  if UpgradeMode and (PriorDisplayVersion = '1.1.0-beta.4') then begin
    Log('KSESSION_REJECT_REGISTERED');
    SuppressibleMsgBox(ExistingMessage, mbError, MB_OK, IDOK); exit;
  end;
#endif
  Result := True;
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
var P, Ancestor, Probe: String; Free, Total: Int64; H: LongWord;
begin
  Result := '';
  ReleaseLocks;
  P := ExpandConstant('{app}');
#ifdef FreshTrial
  if not FreshStartupAbsent or
     not FreshFileAbsent(ExpandConstant('{commonstartup}\K-SESSION Fresh Trial.lnk')) then begin
    Log('KSESSION_FRESH_REJECT_STARTUP'); Result := '登录启动项同名或路径不安全，已拒绝。'; exit;
  end;
  if not FreshFileAbsent(ExpandConstant('{userdesktop}\K⁺-SESSION.lnk')) or
     not FreshFileAbsent(ExpandConstant('{userprograms}\K⁺-SESSION.lnk')) or
     not FreshFileAbsent(ExpandConstant('{commondesktop}\K⁺-SESSION.lnk')) or
     not FreshFileAbsent(ExpandConstant('{commonprograms}\K⁺-SESSION.lnk')) then begin
    Log('KSESSION_FRESH_REJECT_SHORTCUT'); Result := '已有同名快捷方式或路径不可检查，已拒绝。'; exit;
  end;
  if UpgradeMode or FreshRegistrationOrBinding then begin
    Log('KSESSION_FRESH_REJECT_REGISTRATION'); Result := ExistingMessage; exit;
  end;
  if not FreshEmptyLocation(LegacyInstance) or not FreshEmptyLocation(BetaInstance) then begin
    Log('KSESSION_FRESH_REJECT_INSTANCE'); Result := '已有业务实例或数据目录不可检查，已拒绝全新试用。'; exit;
  end;
  if not FreshEmptyLocation(P) then begin
    Log('KSESSION_FRESH_REJECT_TARGET'); Result := '安装目标非空、不安全或不可检查，已拒绝。'; exit;
  end;
#endif
  if not UpgradeMode then begin
    Result := CheckDataLocation(False); if Result <> '' then exit;
    if not ConfirmDataChoice then begin Log('KSESSION_DATA_SWITCH_UNCONFIRMED'); Result := '未确认使用另一数据位置（不会自动迁移）。'; exit; end;
  end;
  if not SafePath(P) then begin Log('KSESSION_REJECT_PATH'); Result := '安装路径无效、包含重解析点或与数据/系统目录重叠。'; exit; end;
  if UpgradeMode then begin
    if not SameInstallRoot(P, PriorInstallRoot) then begin Log('KSESSION_UPGRADE_ROOT_MISMATCH'); Result := '升级安装目录与原登记不一致，已拒绝。'; exit; end;
  end else begin
    if HasRegistration then begin Result := ExistingMessage; exit; end;
    if FileExists(P) or (DirExists(P) and NonEmpty(P)) then begin Log('KSESSION_REJECT_NONEMPTY'); Result := '目标目录不是空目录，拒绝覆盖未知文件。'; exit; end;
    if FileExists(ExpandConstant('{userdesktop}\K⁺-SESSION.lnk')) or FileExists(ExpandConstant('{userprograms}\K⁺-SESSION.lnk')) then begin Result := '已有同名快捷方式，拒绝覆盖。请确认其来源后再安装。'; exit; end;
  end;
  if RunningProduct then begin Log('KSESSION_REJECT_RUNNING'); Result := RunningMessage; exit; end;
  if not AcquireExistingInstanceLock then begin Log('KSESSION_REJECT_INSTANCE_LOCK'); Result := RunningMessage; exit; end;
  Ancestor := P;
  while not DirExists(Ancestor) do Ancestor := ExtractFileDir(Ancestor);
  if not GetSpaceOnDisk64(Ancestor, Free, Total) then begin Log('KSESSION_REJECT_SPACE_QUERY'); Result := '无法确认可用磁盘空间。'; exit; end;
  if Free < {#RequiredBytes} then begin Log('KSESSION_REJECT_SPACE'); Result := '磁盘可用空间不足，未安装程序。'; exit; end;
  { DateSeparator and TimeSeparator are Char, never empty string variants. }
  Probe := AddBackslash(Ancestor) + 'ksession-write-probe-' + GetDateTimeString('yyyymmddhhnnss', '-', ':') + '.tmp';
  H := CreateFileW(Probe, $40000000, 0, 0, 1, $04000100, 0); { CREATE_NEW, delete-on-close }
  if H = $FFFFFFFF then begin Log('KSESSION_REJECT_WRITE'); Result := '当前用户没有目录写入权限。不会请求管理员权限。'; exit; end;
  CloseHandle(H);
  if UpgradeMode then begin
    if not RunUpgradeGate then begin Log('KSESSION_UPGRADE_PREFLIGHT_REJECTED'); Result := '现有安装、数据绑定或业务实例未通过安全升级检查；未修改现有程序或数据。'; exit; end;
    Log('KSESSION_UPGRADE_GATE_ACCEPTED');
#ifdef SequenceDiagnostic
    Log('KSESSION_SEQUENCE_IDENTITY_ACCEPTED');
    Result := '专项诊断已在升级事务和文件复制前停止。';
    exit;
#endif
    if not PrepareUpgradeTransaction then begin Log('KSESSION_UPGRADE_RECOVERY_PREPARE_FAILED'); Result := '无法建立可恢复升级事务；未修改现有程序或数据。'; exit; end;
    Log('KSESSION_UPGRADE_TRANSACTION_PREPARED');
  end;
  Log('KSESSION_PREINSTALL_READY');
end;

procedure EnsureAbsent(Rel: String);
begin
  if FileExists(ExpandConstant('{app}\program\') + Rel) or DirExists(ExpandConstant('{app}\program\') + Rel) then RaiseException('目标文件在检查后出现，拒绝覆盖。');
end;

procedure BeforeUpgradeCopy(Rel: String);
var FaultPath: String;
begin
#ifdef FaultCopy
  if UpgradeMode and not FaultCopyIssued then begin
    FaultCopyIssued := True;
    FaultPath := ExpandConstant('{tmp}\ksession-upgrade-v2\program\') + Rel;
    if ForceDirectories(FaultPath) then
      Log('KSESSION_FIXTURE_COPY_FAILURE: ' + Rel)
    else
      Log('KSESSION_FIXTURE_COPY_INJECTION_PREPARE_FAILED');
    { A directory at the exact destination forces Inno's native file copy to fail.
      Script exceptions from BeforeInstall are intentionally swallowed by Inno. }
  end;
#endif
end;

procedure VerifyInstalled;
begin
#include AddBackslash(Generated) + "verify.iss"
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then begin
    try
      if UpgradeMode then begin
        Log('KSESSION_UPGRADE_NATIVE_COPY_COMPLETE');
        if not CommitUpgradeTransaction then
          RaiseException('升级提交失败；旧程序恢复结果请查看安装日志。');
        TransactionSwapped := True;
        Log('KSESSION_UPGRADE_TRANSACTION_SWAPPED');
      end;
      VerifyInstalled;
      if UpgradeMode then Log('KSESSION_UPGRADE_INSTALLED_VERIFIED');
#ifdef FaultPostCopy
      if UpgradeMode then begin
        Log('KSESSION_FIXTURE_POST_COPY_VERIFY_FAILURE');
        RaiseException('受控安装后校验故障。');
      end;
#endif
      if (not UpgradeMode) and (CheckDataLocation(True) <> '') then RaiseException('无法准备所选数据位置；不会改写已有数据。');
      if (not UpgradeMode) and not WriteFreshInstallState then RaiseException('无法保存安装状态。');
      if not RegWriteStringValue(HKCU64, BindingKey, 'InstallRoot', ExpandConstant('{app}')) or
         not RegWriteStringValue(HKCU64, BindingKey, 'Instance', BetaInstance) then RaiseException('无法记录上次数据位置。');
      if UpgradeMode then begin
        if not FileExists(ExpandConstant('{userdesktop}\K⁺-SESSION.lnk')) or
           not FileExists(ExpandConstant('{userprograms}\K⁺-SESSION.lnk')) then
          RaiseException('升级后的快捷方式验证失败。');
        if not VerifyFinalRegistration then RaiseException('升级后的安装登记或数据绑定验证失败。');
        if not RunNode('upgrade-transaction-cli.cjs', 'finalize "' + UpgradePlan + '"') then
          RaiseException('升级终态验证失败；将尝试恢复旧程序。');
        TransactionFinalized := True;
        Log('KSESSION_UPGRADE_TRANSACTION_COMMITTED');
      end;
#ifdef FreshTrial
      CreateFreshStartup;
      if not FreshReleaseTrustedStartupTarget then RaiseException('无法安全关闭启动程序身份句柄。');
      if not FreshReleaseStartupOwner then RaiseException('无法安全关闭启动项所有权句柄。');
      FreshInstallCompleted := True;
#endif
      ReleaseLocks; { allow first start only after completed checks }
      Log('KSESSION_INSTALLED_PAYLOAD_VERIFIED');
      Log('KSESSION_DESKTOP_LINK=' + ExpandConstant('{userdesktop}\K⁺-SESSION.lnk'));
      Log('KSESSION_START_LINK=' + ExpandConstant('{userprograms}\K⁺-SESSION.lnk'));
    except
      PostInstallFailed := True;
      Log('KSESSION_UPGRADE_POSTINSTALL_FAILED');
#ifdef FreshTrial
      { End the Launcher read lifetime before native failed-install teardown.
        Keep the shortcut producer reference for exact DeinitializeSetup recovery. }
      if not FreshReleaseTrustedStartupTarget then Log('KSESSION_FRESH_STARTUP_CLEANUP_UNPROVEN');
#endif
      RaiseLastException;
    end;
  end;
end;

function GetCustomSetupExitCode: Integer;
begin
  Result := 0;
  if PostInstallFailed then Result := 4;
end;

function CanLaunchInstalled: Boolean;
begin
  Result := not PostInstallFailed and ((not UpgradeMode) or TransactionFinalized);
end;

function LockExecutable(P: String; var H: LongWord): Boolean;
begin
  Result := True;
  if not FileExists(P) then exit;
  H := CreateFileW(P, 0, 4, 0, 3, $80, 0); { only FILE_SHARE_DELETE: block a new launch, allow logged delete }
  Result := H <> $FFFFFFFF;
  if not Result then H := 0;
end;

function InitializeUninstall: Boolean;
begin
  Result := False;
#ifdef FreshTrial
  if not FreshStartupAbsent and not FreshStartupMatches(GetIniString('Startup', 'Sha256', '', ExpandConstant('{app}\uninstall\fresh-startup.ini'))) then begin
    Log('KSESSION_FRESH_UNINSTALL_STARTUP_UNKNOWN'); exit;
  end;
#endif
  if SelectedInstance('') = '' then begin SuppressibleMsgBox('数据绑定缺失，请先修复安装记录；不会猜测其他数据位置。', mbError, MB_OK, IDOK); exit; end;
  if not UninstallSilent then
    if MsgBox('K⁺-SESSION业务数据与附件不会被删除。请先保存并停止服务。继续卸载程序？', mbConfirmation, MB_YESNO) <> IDYES then exit;
  if RunningProduct or not AcquireExistingInstanceLock then begin
    Log('KSESSION_UNINSTALL_REJECT_RUNNING');
    ReleaseLocks; SuppressibleMsgBox(RunningMessage, mbError, MB_OK, IDOK); exit;
  end;
  if not LockExecutable(ExpandConstant('{app}\program\K-SESSION.exe'), LauncherLock) or
     not LockExecutable(ExpandConstant('{app}\program\runtime\node.exe'), NodeLock) then begin
    ReleaseLocks; SuppressibleMsgBox(RunningMessage, mbError, MB_OK, IDOK); exit;
  end;
  Result := True;
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var P: String; Attr, ErrorCode: LongWord;
begin
  if CurUninstallStep <> usUninstall then exit;
#ifdef FreshTrial
  if not FreshStartupAbsent then begin
    if not FreshStartupMatches(GetIniString('Startup', 'Sha256', '', ExpandConstant('{app}\uninstall\fresh-startup.ini'))) then
      RaiseException('登录启动项身份未知，拒绝删除。');
    if not DeleteFile(FreshStartupPath) then RaiseException('无法删除已验证登录启动项。');
  end;
  if not DeleteFile(ExpandConstant('{app}\uninstall\fresh-startup.ini')) then
    RaiseException('无法移除登录启动项身份记录。');
#endif
  P := ExpandConstant('{app}\uninstall\install-state.json');
  if not SafeDirectoryChain(ExtractFileDir(P)) then begin
    Log('KSESSION_UNINSTALL_STATE_REJECTED');
    RaiseException('安装状态目录异常，拒绝删除。');
  end;
  Attr := GetFileAttributesW(P);
  if Attr = $FFFFFFFF then begin
    ErrorCode := GetLastErrorCode;
    if (ErrorCode = 2) or (ErrorCode = 3) then exit; { file/path not found }
    Log('KSESSION_UNINSTALL_STATE_REJECTED');
    RaiseException('无法检查安装状态文件，拒绝继续卸载。');
  end;
  if ((Attr and $400) <> 0) or ((Attr and $10) <> 0) then begin
    Log('KSESSION_UNINSTALL_STATE_REJECTED');
    RaiseException('安装状态文件异常，拒绝删除。');
  end;
  if not DeleteFile(P) then begin
    Log('KSESSION_UNINSTALL_STATE_DELETE_FAILED');
    RaiseException('无法删除安装状态文件。');
  end;
  Log('KSESSION_UNINSTALL_STATE_REMOVED');
end;

procedure DeinitializeSetup;
begin
#ifdef FreshTrial
  if FreshStartupCreated and not FreshInstallCompleted then begin
    FreshStartupCleanupVerified := False; FreshStartupCleanupFailureStage := '';
    FreshStartupContext := 'CLEANUP'; FreshStartupStage('CLEANUP_ENTER');
    FreshStartupContext := 'CLEANUP_VERIFY';
    FreshStartupStage('OWNER_VERIFY_ENTER');
    if FreshRemoveOwnedStartup then begin
      FreshStartupStage('OWNER_VERIFIED');
      FreshStartupCleanupVerified := True; FreshStartupContext := 'CLEANUP';
      FreshStartupStage('CLEANUP_REMOVED');
    end else begin FreshStartupStage('OWNER_REJECTED'); FreshStartupContext := 'CLEANUP'; FreshStartupStage('CLEANUP_IDENTITY_UNKNOWN'); Log('KSESSION_FRESH_STARTUP_CLEANUP_UNKNOWN'); end;
  end;
  if not FreshReleaseStartupOwner then Log('KSESSION_FRESH_STARTUP_CLEANUP_UNPROVEN');
  if not FreshReleaseTrustedStartupTarget then Log('KSESSION_FRESH_STARTUP_CLEANUP_UNPROVEN');
#endif
  if UpgradeMode and TransactionPrepared and not TransactionFinalized then begin
    if RunNode('upgrade-transaction-cli.cjs', 'rollback "' + UpgradePlan + '"') then begin
      if RestoreUpgradeRegistration and
         RunNode('upgrade-transaction-cli.cjs', 'complete-rollback "' + UpgradePlan + '"') then
        Log('KSESSION_UPGRADE_TRANSACTION_ROLLED_BACK')
      else Log('KSESSION_UPGRADE_ROLLBACK_FAILED');
    end else Log('KSESSION_UPGRADE_ROLLBACK_FAILED');
  end;
  ReleaseLocks;
end;
procedure DeinitializeUninstall;
begin ReleaseLocks; end;

procedure CurPageChanged(CurPageID: Integer);
begin
  Log('KSESSION_WIZARD_PAGE_' + IntToStr(CurPageID));
  if CurPageID = DataPage.ID then
    WizardForm.NextButton.Caption := SetupMessage(msgButtonInstall);
end;

#ifdef FaultCancel
procedure CurInstallProgressChanged(CurProgress, MaxProgress: Integer);
begin
  if not FaultCancelIssued and (CurProgress > 0) and (CurProgress < MaxProgress) then begin
    FaultCancelIssued := True;
    Log('KSESSION_FIXTURE_CANCEL_DURING_COPY');
    WizardForm.CancelButton.OnClick(WizardForm.CancelButton);
  end;
end;
procedure CancelButtonClick(CurPageID: Integer; var Cancel, Confirm: Boolean);
begin Cancel := True; Confirm := False; end;
#endif
